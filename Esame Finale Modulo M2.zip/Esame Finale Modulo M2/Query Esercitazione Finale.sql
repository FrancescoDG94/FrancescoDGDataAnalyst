/*1. Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l'univocità dei valori di ciascuna PK 
(una query per tabella implementata)*/
SELECT Product_ID
FROM product
GROUP BY Product_ID
HAVING COUNT(*) > 1;

SELECT Region_ID
FROM region
GROUP BY Region_ID
HAVING COUNT(*) > 1;

SELECT Sales_ID
FROM sales
GROUP BY Sales_ID
HAVING COUNT(*) > 1;

/*2. Esporre l'elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, 
il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data di vendita o meno
(>180 -> True, <= 180 -> False)*/

SELECT
S.Sales_ID AS CODICE_DOCUMENTO,
S.Data AS DATA,
P.Product_Name AS NOME_PRODOTTO,
P.Category_Name AS CATEGORIA_PRODOTTO,
R.State AS NOME_STATO,
R.Region_Name AS NOME_REGIONE,
CASE
WHEN (DATEDIFF(CURDATE(), S.Data) > 180) THEN TRUE
ELSE FALSE
END AS Oltre180giorni 
FROM region as R INNER JOIN sales as S
ON R.Region_ID = S.Region_ID
INNER JOIN product as P
ON S.Product_ID = P.Product_ID;

/* 3. Esporre l'elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell'ultimo anno censito.
(ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto
e il totale venduto.*/
SELECT 
    s.Product_ID,
    SUM(s.Quantità) AS TotaleVenduto
FROM sales s
WHERE YEAR(s.Data) = (
        SELECT MAX(YEAR(Data))
        FROM sales)
GROUP BY s.Product_ID
HAVING SUM(s.Quantità) >
        (SELECT AVG(Quantità)
        FROM sales
        WHERE YEAR(Data) =
                (SELECT MAX(YEAR(Data))
                FROM sales));
    
/*4. Esporre l'elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno*/
SELECT Year (s.Data) as ANNO,
p.Product_Name AS PRODOTTI_VENDUTI,
SUM(Importo) as FATTURATO
FROM sales as s INNER JOIN product as p
ON s.Product_ID = p.Product_ID
GROUP BY Year(s.Data), s.Product_ID
ORDER BY Year(s.Data);


/*5. Esporre il fatturato totale per Stato, per anno. Ordina il risultato per data e per fatturato decrescente.*/
SELECT 
YEAR(sales.Data) AS ANNO,
region.State AS STATO,
SUM(sales.Importo) AS FATTURATO
FROM sales INNER JOIN region
ON sales.Region_ID = region.Region_ID
GROUP BY YEAR(sales.Data), region.State
ORDER BY FATTURATO DESC;

/*6. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?*/
SELECT
p.Category_Name AS CATEGORIA,
SUM(s.Quantità) as VENDUTO
FROM sales as s INNER JOIN product as p
ON s.Product_ID = p.Product_ID 
GROUP BY CATEGORIA
ORDER BY VENDUTO DESC;

/*7. Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti*/
/*OPZIONE 1*/
SELECT
p.Product_Name AS PRODOTTO,
s.Sales_ID IS NULL NON_VENDUTI
FROM product AS p LEFT OUTER JOIN sales AS s
ON p.Product_ID = s.Product_ID
GROUP BY PRODOTTO, s.Sales_ID;
/*OPZIONE 2*/
SELECT
p.Product_Name AS PRODOTTO
FROM product AS p LEFT OUTER JOIN sales AS s
ON p.Product_ID = s.Product_ID
WHERE s.Sales_ID IS NULL;

/*8. Creare una lista sui prodotti in modo tale da esporre una "versione denormalizzata" delle informazioni utili (codice prodotto, nome prodotto, nome categoria)*/
SELECT
p.Product_ID AS CODICE_PRODOTTO,
p.Product_Name AS NOME_PRODOTTO,
p.Category_Name AS CATEGORIA,
SUM(s.Quantità) AS TOT_VENDUTO,
SUM(s.Importo) AS FATTURATO
FROM product AS p INNER JOIN sales AS s
ON p.Product_ID = s.Product_ID
GROUP BY CODICE_PRODOTTO, NOME_PRODOTTO, CATEGORIA;

/*9. Creare una lista per le informazioni geografiche*/
SELECT
r.State AS STATO,
r.Region_Name AS REGIONE,
SUM(s.Importo) AS FATTURATO,
SUM(s.Quantità) AS TOT_VENDUTO
FROM product AS p INNER JOIN sales AS s
ON p.Product_ID = s.Product_ID
INNER JOIN region AS r 
ON s.Region_ID = r.Region_ID
GROUP BY STATO, REGIONE
ORDER BY FATTURATO DESC;